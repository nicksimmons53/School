public class PCB {
	String line[ ];

	public void PCB(String parsedLine[ ]) {

	}
}
